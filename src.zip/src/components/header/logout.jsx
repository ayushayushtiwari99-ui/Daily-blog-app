import React from 'react'
import {useDispatch} from 'react-redux'
import authservice from '../../appwrite/auth.js'
import {logout} from '../../store/authslice.js'

function Logout() {

    const dispatch = useDispatch()
    const logoutHandler = () => {
        authservice.logout().then(() => {
            dispatch(logout())
        })
    }

  return (
      <button className=''>logout</button>
  )
}

export default Logout