import React from 'react'
import {Container ,Logout} from '../index.js'
import {Link, Navigate, useNavigate} from 'react-router-dom'
import { useSelector } from 'react-redux'

function Header() {
  const authStatus = useSelector( (state) => state.auth.status )
  const usenavigate = useNavigate()
  
  const naitem = [
    {
      name: 'home',
      slug: "/",
      active: true,
    },
    {
      name: "login",
      slug: "/login",
      active: !authStatus,
    },
    {
      name: "signup",
      slug: "/signup",
      active: !authStatus,
    },
    {
      name: "all posts",
      slug: "/all-posts",
      active: authStatus,
    },
    {
      name: "add post",
      slug: "/add-post",
      active: authStatus,
    }
  ]
  return (
    <header className=''>
      <container>
        <nav className=''>
          <div>
            <Link to="/">
            logo
            </Link>
          </div>
          <ul className=''>
             {naitem.map( () => (item))}
             item.active ? (
              <li key={item.name}>
                <button onClick={() => Navigat(item.slug)} className=''>{item.name}</button>
              </li>
              ) : null

              {authStatus && (
                <li>
                  logout btn
                </li>
              )}
          </ul>
        </nav>
      </container>
    </header>
  )
}

export default Header