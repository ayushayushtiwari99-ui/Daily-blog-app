import React from 'react';
import '../css/footer.css';

function Footer() {
  return (
    <footer className="footer">
      <div className="footer-content">
        <span className="footer-author">&copy; {new Date().getFullYear()} Ayush Tiwari</span>
        <div className="footer-info">
          <a href="tel:+919076228643">+91 90762 28643</a>
          <span className="dot">&bull;</span>
          <a href="mailto:ayush.ayushtiwari.99@gmail.com">ayush.ayushtiwari.99@gmail.com</a>
        </div>
      </div>
    </footer>
  );
}

export default Footer;

