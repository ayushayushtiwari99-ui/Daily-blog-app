import React from 'react'

function container(children) {
  return (
    <div className=''>
        {children}
    </div>

  )
}

export default container