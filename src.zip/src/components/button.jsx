import React, { Children ,bg} from 'react'

function button(children) {
    
  return (
    <button style={{backgroundColor: {bg}}}>{Children}</button>
  )
}

export default button