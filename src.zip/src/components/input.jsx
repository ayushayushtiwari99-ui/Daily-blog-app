import React, {useId} from 'react'

const input = React.forwardRef(function input(
   labal,
   placeholder="input here",
){
  return (
    <div className=''>
    <input style={{placeholder: {placeholder}}} ref={ref} />
    </div>
  )
})

export default input